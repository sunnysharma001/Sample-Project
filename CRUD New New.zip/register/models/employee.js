var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var EmployeeSchema = new Schema({
	_id: { type: String, unique: true, required: true},
	fullname: { type: String},
	email: { type: String},
	mobile: { type: String},
	created_on : { type: Date},
	status : { type: Number}
	
});

var collectionName = 'employee';
var Employee = mongoose.model('Employee', EmployeeSchema, collectionName);
//module.exports = Employee;
module.exports = mongoose.model('employee', EmployeeSchema);