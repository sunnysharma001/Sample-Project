var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var StudentSchema = new Schema({
	_id: { type: String, unique: true, required: true},
	fullname: { type: String},
	collegename: { type: String},
	yob:{type:Date},
    country: { type:String},
	gender:{type:String},
	hostel: {type: String},
	created_on : { type: Date},
	status : { type: Number}
});
var collectionName = 'student';
var Student = mongoose.model('Student', StudentSchema, collectionName);
//module.exports = Student;
module.exports = mongoose.model('student', StudentSchema);
