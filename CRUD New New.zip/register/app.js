
var express = require('express');
var path = require('path');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var cons = require('consolidate');
var http = require('http');

mongoose.connect('mongodb://127.0.0.1:27017/ielp', { useMongoClient: true });
mongoose.set('useCreateIndex', true);
var db = mongoose.connection;


var employeeRoute = require('./routes/EmployeeRoute');

var studentRoute = require('./routes/StudentRoute');

var app = express();

app.engine('html', cons.swig)
app.set('views', path.join(__dirname, '/views'));
app.set('view engine', 'html');

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: false }));

app.get('/', function(req, res){
  res.render("index");
});

app.get('/std', function(req, res){
  res.render("student");
});

app.get('/emp', function(req, res){
  res.render("employee");
});


app.use('/employee', employeeRoute);
app.use('/student', studentRoute);

app.listen(7640);
console.log("Server is listening on port number 7640");
console.log("Hit URL http://localhost:7640/");
module.exports = app