var express = require('express');
var router = express.Router();
var objectID = require('mongodb').ObjectID;

var Student = require('../models/student');

router.get('/all', function(req, res){
    Student.find({status :0}, function (err, students) {
        if(err) res.status(500).send("Unable to fetch students data"); 
        else res.status(200).json(students);
    })
});

router.post('/add' , function(req, res){
    var newStudent = new Student(req.body);
    newStudent._id = new objectID();
    newStudent.created_on = new Date();
    newStudent.status = 0;
    newStudent.save(function(err, student){
        if (err) res.status(500).send("Saving Error"); 
        else res.status(200).json(student);
    })
});
router.post('/edit' , function(req, res){
    Student.findOne({_id: req.body._id}, function(err, student){
        student.fullname = req.body.fullname;
        student.collegename= req.body.collegename;
        student.yob=req.body.yob;
        student.gender=req.body.gender;
        student.country=req.body.country;
        student.hostel=req.body.hostel;
        student.save(function(saveError, savedStudent){
            if (saveError) res.status(500).send("Saving Error"); 
            else res.status(200).json(savedStudent);
        })
    })
    
});
router.post('/del',function(req,res){
    Student.findByIdAndRemove({_id: req.body._id},function(err,student){
        if(err)res.status(500).send("error");
        else res.status(200).json(student);
    })
})

module.exports = router;

