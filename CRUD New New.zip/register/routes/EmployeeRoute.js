var express = require('express');
var router = express.Router();
var objectID = require('mongodb').ObjectID;

var Employee = require('../models/employee');

router.get('/all', function(req, res){
    Employee.find({status :0}, function (err, employees) {
        if(err) res.status(500).send("Unable to fetch employee data"); 
        else res.status(200).json(employees);
    })
});

router.post('/add' , function(req, res){
    var newEmployee = new Employee(req.body);
    newEmployee._id = new objectID();
    newEmployee.created_on = new Date();
    newEmployee.status = 0;
    newEmployee.save(function(err, employee){
        if (err) res.status(500).send("Saving Error"); 
        else res.status(200).json(employee);
    })
});
router.post('/edit' , function(req, res){
    Employee.findOne({_id: req.body._id}, function(err, employee){
        employee.fullname = req.body.fullname;
        employee.email= req.body.email;
        employee.mobile= req.body.mobile;
        employee.save(function(saveError, savedEmployee){
            if (saveError) res.status(500).send("Saving Error"); 
            else res.status(200).json(savedEmployee);
        })
    })
    
});
router.post('/del',function(req,res){
    Employee.findByIdAndRemove({_id: req.body._id},function(err,employee){
        if(err)res.status(500).send("error");
        else res.status(200).json(employee);
    })
})

module.exports = router;

